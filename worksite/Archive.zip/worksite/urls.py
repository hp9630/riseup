"""
URL configuration for worksite project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from App import views
from django.conf import settings
from django.urls import path,include
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),

    path('captcha_image/', views.captcha_image, name='captcha_image'),

    path('',views.Homepage,name='index'),
    # path('registration/signup/',views.signup,name='signup'),
    path('accounts/',include('django.contrib.auth.urls')),
    path('adminmain/',views.adminmain,name='adminmain'),
     path('addwork/',views.addwork,name='addwork'),
    path('viewwork/',views.viewwork,name='viewwork'),
    
    path('editwork(<int:id>)',views.editwork,name='editwork'),
    path('updatework(<int:id>)',views.updatework,name='updatework'),
    path('editwork1(<int:id>)',views.editwork1,name='editwork1'),
    path('sendwork(<int:id>)',views.sendwork,name='sendwork'),
    path('image/',views.usersave,name='capture'),
    path('upload/',views.upload_image, name='upload_image'),
        ###whatsapp
    path('base/',views.base,name='base'),
    
    path('whatsapp/',views.whatsapp,name='whatsapp'),
    path('whatsapp/senddata',views.senddata,name='senddata'),
    path('getinvoice1(<int:id>)',views.getinvoice1,name='getinvoice1'),
    path('editinvoice1(<int:id>)',views.editinvoice1,name='editinvoice1'),
    path('finalinvoice1/',views.finalinvoice1,name='finalinvoice1'),

]
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)

