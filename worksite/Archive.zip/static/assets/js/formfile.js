var q = null;
window.PR_SHOULD_USE_CONTINUATION = !0;
(function () {
  function L(a) {
    function m(a) {
      var f = a.charCodeAt(0);
      if (f !== 92) return f;
      var b = a.charAt(1);
      return (f = r[b])
        ? f
        : "0" <= b && b <= "7"
        ? parseInt(a.substring(1), 8)
        : b === "u" || b === "x"
        ? parseInt(a.substring(2), 16)
        : a.charCodeAt(1);
    }
    function e(a) {
      if (a < 32) return (a < 16 ? "\\x0" : "\\x") + a.toString(16);
      a = String.fromCharCode(a);
      if (a === "\\" || a === "-" || a === "[" || a === "]") a = "\\" + a;
      return a;
    }
    function h(a) {
      for (
        var f = a
            .substring(1, a.length - 1)
            .match(
              /\\u[\dA-Fa-f]{4}|\\x[\dA-Fa-f]{2}|\\[0-3][0-7]{0,2}|\\[0-7]{1,2}|\\[\S\s]|[^\\]/g
            ),
          a = [],
          b = [],
          o = f[0] === "^",
          c = o ? 1 : 0,
          i = f.length;
        c < i;
        ++c
      ) {
        var j = f[c];
        if (/\\[bdsw]/i.test(j)) a.push(j);
        else {
          var j = m(j),
            d;
          c + 2 < i && "-" === f[c + 1]
            ? ((d = m(f[c + 2])), (c += 2))
            : (d = j);
          b.push([j, d]);
          d < 65 ||
            j > 122 ||
            (d < 65 ||
              j > 90 ||
              b.push([Math.max(65, j) | 32, Math.min(d, 90) | 32]),
            d < 97 ||
              j > 122 ||
              b.push([Math.max(97, j) & -33, Math.min(d, 122) & -33]));
        }
      }
      b.sort(function (a, f) {
        return a[0] - f[0] || f[1] - a[1];
      });
      f = [];
      j = [NaN, NaN];
      for (c = 0; c < b.length; ++c)
        (i = b[c]),
          i[0] <= j[1] + 1 ? (j[1] = Math.max(j[1], i[1])) : f.push((j = i));
      b = ["["];
      o && b.push("^");
      b.push.apply(b, a);
      for (c = 0; c < f.length; ++c)
        (i = f[c]),
          b.push(e(i[0])),
          i[1] > i[0] && (i[1] + 1 > i[0] && b.push("-"), b.push(e(i[1])));
      b.push("]");
      return b.join("");
    }
    function y(a) {
      for (
        var f = a.source.match(
            /\[(?:[^\\\]]|\\[\S\s])*]|\\u[\dA-Fa-f]{4}|\\x[\dA-Fa-f]{2}|\\\d+|\\[^\dux]|\(\?[!:=]|[()^]|[^()[\\^]+/g
          ),
          b = f.length,
          d = [],
          c = 0,
          i = 0;
        c < b;
        ++c
      ) {
        var j = f[c];
        j === "("
          ? ++i
          : "\\" === j.charAt(0) &&
            (j = +j.substring(1)) &&
            j <= i &&
            (d[j] = -1);
      }
      for (c = 1; c < d.length; ++c) -1 === d[c] && (d[c] = ++t);
      for (i = c = 0; c < b; ++c)
        (j = f[c]),
          j === "("
            ? (++i, d[i] === void 0 && (f[c] = "(?:"))
            : "\\" === j.charAt(0) &&
              (j = +j.substring(1)) &&
              j <= i &&
              (f[c] = "\\" + d[i]);
      for (i = c = 0; c < b; ++c)
        "^" === f[c] && "^" !== f[c + 1] && (f[c] = "");
      if (a.ignoreCase && s)
        for (c = 0; c < b; ++c)
          (j = f[c]),
            (a = j.charAt(0)),
            j.length >= 2 && a === "["
              ? (f[c] = h(j))
              : a !== "\\" &&
                (f[c] = j.replace(/[A-Za-z]/g, function (a) {
                  a = a.charCodeAt(0);
                  return "[" + String.fromCharCode(a & -33, a | 32) + "]";
                }));
      return f.join("");
    }
    for (var t = 0, s = !1, l = !1, p = 0, d = a.length; p < d; ++p) {
      var g = a[p];
      if (g.ignoreCase) l = !0;
      else if (
        /[a-z]/i.test(
          g.source.replace(/\\u[\da-f]{4}|\\x[\da-f]{2}|\\[^UXux]/gi, "")
        )
      ) {
        s = !0;
        l = !1;
        break;
      }
    }
    for (
      var r = { b: 8, t: 9, n: 10, v: 11, f: 12, r: 13 },
        n = [],
        p = 0,
        d = a.length;
      p < d;
      ++p
    ) {
      g = a[p];
      if (g.global || g.multiline) throw Error("" + g);
      n.push("(?:" + y(g) + ")");
    }
    return RegExp(n.join("|"), l ? "gi" : "g");
  }
  function M(a) {
    function m(a) {
      switch (a.nodeType) {
        case 1:
          if (e.test(a.className)) break;
          for (var g = a.firstChild; g; g = g.nextSibling) m(g);
          g = a.nodeName;
          if ("BR" === g || "LI" === g)
            (h[s] = "\n"), (t[s << 1] = y++), (t[(s++ << 1) | 1] = a);
          break;
        case 3:
        case 4:
          (g = a.nodeValue),
            g.length &&
              ((g = p
                ? g.replace(/\r\n?/g, "\n")
                : g.replace(/[\t\n\r ]+/g, " ")),
              (h[s] = g),
              (t[s << 1] = y),
              (y += g.length),
              (t[(s++ << 1) | 1] = a));
      }
    }
    var e = /(?:^|\s)nocode(?:\s|$)/,
      h = [],
      y = 0,
      t = [],
      s = 0,
      l;
    a.currentStyle
      ? (l = a.currentStyle.whiteSpace)
      : window.getComputedStyle &&
        (l = document.defaultView
          .getComputedStyle(a, q)
          .getPropertyValue("white-space"));
    var p = l && "pre" === l.substring(0, 3);
    m(a);
    return { a: h.join("").replace(/\n$/, ""), c: t };
  }
  function B(a, m, e, h) {
    m && ((a = { a: m, d: a }), e(a), h.push.apply(h, a.e));
  }
  function x(a, m) {
    function e(a) {
      for (
        var l = a.d,
          p = [l, "pln"],
          d = 0,
          g = a.a.match(y) || [],
          r = {},
          n = 0,
          z = g.length;
        n < z;
        ++n
      ) {
        var f = g[n],
          b = r[f],
          o = void 0,
          c;
        if (typeof b === "string") c = !1;
        else {
          var i = h[f.charAt(0)];
          if (i) (o = f.match(i[1])), (b = i[0]);
          else {
            for (c = 0; c < t; ++c)
              if (((i = m[c]), (o = f.match(i[1])))) {
                b = i[0];
                break;
              }
            o || (b = "pln");
          }
          if (
            (c = b.length >= 5 && "lang-" === b.substring(0, 5)) &&
            !(o && typeof o[1] === "string")
          )
            (c = !1), (b = "src");
          c || (r[f] = b);
        }
        i = d;
        d += f.length;
        if (c) {
          c = o[1];
          var j = f.indexOf(c),
            k = j + c.length;
          o[2] && ((k = f.length - o[2].length), (j = k - c.length));
          b = b.substring(5);
          B(l + i, f.substring(0, j), e, p);
          B(l + i + j, c, C(b, c), p);
          B(l + i + k, f.substring(k), e, p);
        } else p.push(l + i, b);
      }
      a.e = p;
    }
    var h = {},
      y;
    (function () {
      for (
        var e = a.concat(m), l = [], p = {}, d = 0, g = e.length;
        d < g;
        ++d
      ) {
        var r = e[d],
          n = r[3];
        if (n) for (var k = n.length; --k >= 0; ) h[n.charAt(k)] = r;
        r = r[1];
        n = "" + r;
        p.hasOwnProperty(n) || (l.push(r), (p[n] = q));
      }
      l.push(/[\S\s]/);
      y = L(l);
    })();
    var t = m.length;
    return e;
  }
  function u(a) {
    var m = [],
      e = [];
    a.tripleQuotedStrings
      ? m.push([
          "str",
          /^(?:'''(?:[^'\\]|\\[\S\s]|''?(?=[^']))*(?:'''|$)|"""(?:[^"\\]|\\[\S\s]|""?(?=[^"]))*(?:"""|$)|'(?:[^'\\]|\\[\S\s])*(?:'|$)|"(?:[^"\\]|\\[\S\s])*(?:"|$))/,
          q,
          "'\""
        ])
      : a.multiLineStrings
      ? m.push([
          "str",
          /^(?:'(?:[^'\\]|\\[\S\s])*(?:'|$)|"(?:[^"\\]|\\[\S\s])*(?:"|$)|`(?:[^\\`]|\\[\S\s])*(?:`|$))/,
          q,
          "'\"`"
        ])
      : m.push([
          "str",
          /^(?:'(?:[^\n\r'\\]|\\.)*(?:'|$)|"(?:[^\n\r"\\]|\\.)*(?:"|$))/,
          q,
          "\"'"
        ]);
    a.verbatimStrings && e.push(["str", /^@"(?:[^"]|"")*(?:"|$)/, q]);
    var h = a.hashComments;
    h &&
      (a.cStyleComments
        ? (h > 1
            ? m.push(["com", /^#(?:##(?:[^#]|#(?!##))*(?:###|$)|.*)/, q, "#"])
            : m.push([
                "com",
                /^#(?:(?:define|elif|else|endif|error|ifdef|include|ifndef|line|pragma|undef|warning)\b|[^\n\r]*)/,
                q,
                "#"
              ]),
          e.push([
            "str",
            /^<(?:(?:(?:\.\.\/)*|\/?)(?:[\w-]+(?:\/[\w-]+)+)?[\w-]+\.h|[a-z]\w*)>/,
            q
          ]))
        : m.push(["com", /^#[^\n\r]*/, q, "#"]));
    a.cStyleComments &&
      (e.push(["com", /^\/\/[^\n\r]*/, q]),
      e.push(["com", /^\/\*[\S\s]*?(?:\*\/|$)/, q]));
    a.regexLiterals &&
      e.push([
        "lang-regex",
        /^(?:^^\.?|[!+-]|!=|!==|#|%|%=|&|&&|&&=|&=|\(|\*|\*=|\+=|,|-=|->|\/|\/=|:|::|;|<|<<|<<=|<=|=|==|===|>|>=|>>|>>=|>>>|>>>=|[?@[^]|\^=|\^\^|\^\^=|{|\||\|=|\|\||\|\|=|~|break|case|continue|delete|do|else|finally|instanceof|return|throw|try|typeof)\s*(\/(?=[^*/])(?:[^/[\\]|\\[\S\s]|\[(?:[^\\\]]|\\[\S\s])*(?:]|$))+\/)/
      ]);
    (h = a.types) && e.push(["typ", h]);
    a = ("" + a.keywords).replace(/^ | $/g, "");
    a.length &&
      e.push(["kwd", RegExp("^(?:" + a.replace(/[\s,]+/g, "|") + ")\\b"), q]);
    m.push(["pln", /^\s+/, q, " \r\n\t\xa0"]);
    e.push(
      ["lit", /^@[$_a-z][\w$@]*/i, q],
      ["typ", /^(?:[@_]?[A-Z]+[a-z][\w$@]*|\w+_t\b)/, q],
      ["pln", /^[$_a-z][\w$@]*/i, q],
      [
        "lit",
        /^(?:0x[\da-f]+|(?:\d(?:_\d+)*\d*(?:\.\d*)?|\.\d\+)(?:e[+-]?\d+)?)[a-z]*/i,
        q,
        "0123456789"
      ],
      ["pln", /^\\[\S\s]?/, q],
      ["pun", /^.[^\s\w"-$'./@\\`]*/, q]
    );
    return x(m, e);
  }
  function D(a, m) {
    function e(a) {
      switch (a.nodeType) {
        case 1:
          if (k.test(a.className)) break;
          if ("BR" === a.nodeName)
            h(a), a.parentNode && a.parentNode.removeChild(a);
          else for (a = a.firstChild; a; a = a.nextSibling) e(a);
          break;
        case 3:
        case 4:
          if (p) {
            var b = a.nodeValue,
              d = b.match(t);
            if (d) {
              var c = b.substring(0, d.index);
              a.nodeValue = c;
              (b = b.substring(d.index + d[0].length)) &&
                a.parentNode.insertBefore(s.createTextNode(b), a.nextSibling);
              h(a);
              c || a.parentNode.removeChild(a);
            }
          }
      }
    }
    function h(a) {
      function b(a, d) {
        var e = d ? a.cloneNode(!1) : a,
          f = a.parentNode;
        if (f) {
          var f = b(f, 1),
            g = a.nextSibling;
          f.appendChild(e);
          for (var h = g; h; h = g) (g = h.nextSibling), f.appendChild(h);
        }
        return e;
      }
      for (; !a.nextSibling; ) if (((a = a.parentNode), !a)) return;
      for (
        var a = b(a.nextSibling, 0), e;
        (e = a.parentNode) && e.nodeType === 1;

      )
        a = e;
      d.push(a);
    }
    var k = /(?:^|\s)nocode(?:\s|$)/,
      t = /\r\n?|\n/,
      s = a.ownerDocument,
      l;
    a.currentStyle
      ? (l = a.currentStyle.whiteSpace)
      : window.getComputedStyle &&
        (l = s.defaultView
          .getComputedStyle(a, q)
          .getPropertyValue("white-space"));
    var p = l && "pre" === l.substring(0, 3);
    for (l = s.createElement("LI"); a.firstChild; ) l.appendChild(a.firstChild);
    for (var d = [l], g = 0; g < d.length; ++g) e(d[g]);
    m === (m | 0) && d[0].setAttribute("value", m);
    var r = s.createElement("OL");
    r.className = "linenums";
    for (var n = Math.max(0, (m - 1) | 0) || 0, g = 0, z = d.length; g < z; ++g)
      (l = d[g]),
        (l.className = "L" + ((g + n) % 10)),
        l.firstChild || l.appendChild(s.createTextNode("\xa0")),
        r.appendChild(l);
    a.appendChild(r);
  }
  function k(a, m) {
    for (var e = m.length; --e >= 0; ) {
      var h = m[e];
      A.hasOwnProperty(h)
        ? window.console &&
          console.warn("cannot override language handler %s", h)
        : (A[h] = a);
    }
  }
  function C(a, m) {
    if (!a || !A.hasOwnProperty(a))
      a = /^\s*</.test(m) ? "default-markup" : "default-code";
    return A[a];
  }
  function E(a) {
    var m = a.g;
    try {
      var e = M(a.h),
        h = e.a;
      a.a = h;
      a.c = e.c;
      a.d = 0;
      C(m, h)(a);
      var k = /\bMSIE\b/.test(navigator.userAgent),
        m = /\n/g,
        t = a.a,
        s = t.length,
        e = 0,
        l = a.c,
        p = l.length,
        h = 0,
        d = a.e,
        g = d.length,
        a = 0;
      d[g] = s;
      var r, n;
      for (n = r = 0; n < g; )
        d[n] !== d[n + 2] ? ((d[r++] = d[n++]), (d[r++] = d[n++])) : (n += 2);
      g = r;
      for (n = r = 0; n < g; ) {
        for (
          var z = d[n], f = d[n + 1], b = n + 2;
          b + 2 <= g && d[b + 1] === f;

        )
          b += 2;
        d[r++] = z;
        d[r++] = f;
        n = b;
      }
      for (d.length = r; h < p; ) {
        var o = l[h + 2] || s,
          c = d[a + 2] || s,
          b = Math.min(o, c),
          i = l[h + 1],
          j;
        if (i.nodeType !== 1 && (j = t.substring(e, b))) {
          k && (j = j.replace(m, "\r"));
          i.nodeValue = j;
          var u = i.ownerDocument,
            v = u.createElement("SPAN");
          v.className = d[a + 1];
          var x = i.parentNode;
          x.replaceChild(v, i);
          v.appendChild(i);
          e < o &&
            ((l[h + 1] = i = u.createTextNode(t.substring(b, o))),
            x.insertBefore(i, v.nextSibling));
        }
        e = b;
        e >= o && (h += 2);
        e >= c && (a += 2);
      }
    } catch (w) {
      "console" in window && console.log(w && w.stack ? w.stack : w);
    }
  }
  var v = ["break,continue,do,else,for,if,return,while"],
    w = [
      [
        v,
        "auto,case,char,const,default,double,enum,extern,float,goto,int,long,register,short,signed,sizeof,static,struct,switch,typedef,union,unsigned,void,volatile"
      ],
      "catch,class,delete,false,import,new,operator,private,protected,public,this,throw,true,try,typeof"
    ],
    F = [
      w,
      "alignof,align_union,asm,axiom,bool,concept,concept_map,const_cast,constexpr,decltype,dynamic_cast,explicit,export,friend,inline,late_check,mutable,namespace,nullptr,reinterpret_cast,static_assert,static_cast,template,typeid,typename,using,virtual,where"
    ],
    G = [
      w,
      "abstract,boolean,byte,extends,final,finally,implements,import,instanceof,null,native,package,strictfp,super,synchronized,throws,transient"
    ],
    H = [
      G,
      "as,base,by,checked,decimal,delegate,descending,dynamic,event,fixed,foreach,from,group,implicit,in,interface,internal,into,is,lock,object,out,override,orderby,params,partial,readonly,ref,sbyte,sealed,stackalloc,string,select,uint,ulong,unchecked,unsafe,ushort,var"
    ],
    w = [
      w,
      "debugger,eval,export,function,get,null,set,undefined,var,with,Infinity,NaN"
    ],
    I = [
      v,
      "and,as,assert,class,def,del,elif,except,exec,finally,from,global,import,in,is,lambda,nonlocal,not,or,pass,print,raise,try,with,yield,False,True,None"
    ],
    J = [
      v,
      "alias,and,begin,case,class,def,defined,elsif,end,ensure,false,in,module,next,nil,not,or,redo,rescue,retry,self,super,then,true,undef,unless,until,when,yield,BEGIN,END"
    ],
    v = [v, "case,done,elif,esac,eval,fi,function,in,local,set,then,until"],
    K = /^(DIR|FILE|vector|(de|priority_)?queue|list|stack|(const_)?iterator|(multi)?(set|map)|bitset|u?(int|float)\d*)/,
    N = /\S/,
    O = u({
      keywords: [
        F,
        H,
        w,
        "caller,delete,die,do,dump,elsif,eval,exit,foreach,for,goto,if,import,last,local,my,next,no,our,print,package,redo,require,sub,undef,unless,until,use,wantarray,while,BEGIN,END" +
          I,
        J,
        v
      ],
      hashComments: !0,
      cStyleComments: !0,
      multiLineStrings: !0,
      regexLiterals: !0
    }),
    A = {};
  k(O, ["default-code"]);
  k(
    x(
      [],
      [
        ["pln", /^[^<?]+/],
        ["dec", /^<!\w[^>]*(?:>|$)/],
        ["com", /^<\!--[\S\s]*?(?:--\>|$)/],
        ["lang-", /^<\?([\S\s]+?)(?:\?>|$)/],
        ["lang-", /^<%([\S\s]+?)(?:%>|$)/],
        ["pun", /^(?:<[%?]|[%?]>)/],
        ["lang-", /^<xmp\b[^>]*>([\S\s]+?)<\/xmp\b[^>]*>/i],
        ["lang-js", /^<script\b[^>]*>([\S\s]*?)(<\/script\b[^>]*>)/i],
        ["lang-css", /^<style\b[^>]*>([\S\s]*?)(<\/style\b[^>]*>)/i],
        ["lang-in.tag", /^(<\/?[a-z][^<>]*>)/i]
      ]
    ),
    ["default-markup", "htm", "html", "mxml", "xhtml", "xml", "xsl"]
  );
  k(
    x(
      [
        ["pln", /^\s+/, q, " \t\r\n"],
        ["atv", /^(?:"[^"]*"?|'[^']*'?)/, q, "\"'"]
      ],
      [
        ["tag", /^^<\/?[a-z](?:[\w-.:]*\w)?|\/?>$/i],
        ["atn", /^(?!style[\s=]|on)[a-z](?:[\w:-]*\w)?/i],
        ["lang-uq.val", /^=\s*([^\s"'>]*(?:[^\s"'/>]|\/(?=\s)))/],
        ["pun", /^[/<->]+/],
        ["lang-js", /^on\w+\s*=\s*"([^"]+)"/i],
        ["lang-js", /^on\w+\s*=\s*'([^']+)'/i],
        ["lang-js", /^on\w+\s*=\s*([^\s"'>]+)/i],
        ["lang-css", /^style\s*=\s*"([^"]+)"/i],
        ["lang-css", /^style\s*=\s*'([^']+)'/i],
        ["lang-css", /^style\s*=\s*([^\s"'>]+)/i]
      ]
    ),
    ["in.tag"]
  );
  k(x([], [["atv", /^[\S\s]+/]]), ["uq.val"]);
  k(u({ keywords: F, hashComments: !0, cStyleComments: !0, types: K }), [
    "c",
    "cc",
    "cpp",
    "cxx",
    "cyc",
    "m"
  ]);
  k(u({ keywords: "null,true,false" }), ["json"]);
  k(
    u({
      keywords: H,
      hashComments: !0,
      cStyleComments: !0,
      verbatimStrings: !0,
      types: K
    }),
    ["cs"]
  );
  k(u({ keywords: G, cStyleComments: !0 }), ["java"]);
  k(u({ keywords: v, hashComments: !0, multiLineStrings: !0 }), [
    "bsh",
    "csh",
    "sh"
  ]);
  k(
    u({
      keywords: I,
      hashComments: !0,
      multiLineStrings: !0,
      tripleQuotedStrings: !0
    }),
    ["cv", "py"]
  );
  k(
    u({
      keywords:
        "caller,delete,die,do,dump,elsif,eval,exit,foreach,for,goto,if,import,last,local,my,next,no,our,print,package,redo,require,sub,undef,unless,until,use,wantarray,while,BEGIN,END",
      hashComments: !0,
      multiLineStrings: !0,
      regexLiterals: !0
    }),
    ["perl", "pl", "pm"]
  );
  k(
    u({
      keywords: J,
      hashComments: !0,
      multiLineStrings: !0,
      regexLiterals: !0
    }),
    ["rb"]
  );
  k(u({ keywords: w, cStyleComments: !0, regexLiterals: !0 }), ["js"]);
  k(
    u({
      keywords:
        "all,and,by,catch,class,else,extends,false,finally,for,if,in,is,isnt,loop,new,no,not,null,of,off,on,or,return,super,then,true,try,unless,until,when,while,yes",
      hashComments: 3,
      cStyleComments: !0,
      multilineStrings: !0,
      tripleQuotedStrings: !0,
      regexLiterals: !0
    }),
    ["coffee"]
  );
  k(x([], [["str", /^[\S\s]+/]]), ["regex"]);
  window.prettyPrintOne = function (a, m, e) {
    var h = document.createElement("PRE");
    h.innerHTML = a;
    e && D(h, e);
    E({ g: m, i: e, h: h });
    return h.innerHTML;
  };
  window.prettyPrint = function (a) {
    function m() {
      for (
        var e = window.PR_SHOULD_USE_CONTINUATION ? l.now() + 250 : Infinity;
        p < h.length && l.now() < e;
        p++
      ) {
        var n = h[p],
          k = n.className;
        if (k.indexOf("prettyprint") >= 0) {
          var k = k.match(g),
            f,
            b;
          if ((b = !k)) {
            b = n;
            for (var o = void 0, c = b.firstChild; c; c = c.nextSibling)
              var i = c.nodeType,
                o =
                  i === 1
                    ? o
                      ? b
                      : c
                    : i === 3
                    ? N.test(c.nodeValue)
                      ? b
                      : o
                    : o;
            b = (f = o === b ? void 0 : o) && "CODE" === f.tagName;
          }
          b && (k = f.className.match(g));
          k && (k = k[1]);
          b = !1;
          for (o = n.parentNode; o; o = o.parentNode)
            if (
              (o.tagName === "pre" ||
                o.tagName === "code" ||
                o.tagName === "xmp") &&
              o.className &&
              o.className.indexOf("prettyprint") >= 0
            ) {
              b = !0;
              break;
            }
          b ||
            ((b = (b = n.className.match(/\blinenums\b(?::(\d+))?/))
              ? b[1] && b[1].length
                ? +b[1]
                : !0
              : !1) && D(n, b),
            (d = { g: k, h: n, i: b }),
            E(d));
        }
      }
      p < h.length ? setTimeout(m, 250) : a && a();
    }
    for (
      var e = [
          document.getElementsByTagName("pre"),
          document.getElementsByTagName("code"),
          document.getElementsByTagName("xmp")
        ],
        h = [],
        k = 0;
      k < e.length;
      ++k
    )
      for (var t = 0, s = e[k].length; t < s; ++t) h.push(e[k][t]);
    var e = q,
      l = Date;
    l.now ||
      (l = {
        now: function () {
          return +new Date();
        }
      });
    var p = 0,
      d,
      g = /\blang(?:uage)?-([\w.]+)(?!\S)/;
    m();
  };
  window.PR = {
    createSimpleLexer: x,
    registerLangHandler: k,
    sourceDecorator: u,
    PR_ATTRIB_NAME: "atn",
    PR_ATTRIB_VALUE: "atv",
    PR_COMMENT: "com",
    PR_DECLARATION: "dec",
    PR_KEYWORD: "kwd",
    PR_LITERAL: "lit",
    PR_NOCODE: "nocode",
    PR_PLAIN: "pln",
    PR_PUNCTUATION: "pun",
    PR_SOURCE: "src",
    PR_STRING: "str",
    PR_TAG: "tag",
    PR_TYPE: "typ"
  };
})();

!(function ($) {
  $(function () {
    $(".dropdown-toggle").dropdown();

    $(".navbar").scrollspy();

    $(".collapse").collapse();

    // make code pretty
    window.prettyPrint && prettyPrint();
  });
})(window.jQuery);
/* ==========================================================
 * bootstrap-alert.js v2.0.1
 * https://twitter.github.com/bootstrap/javascript.html#alerts
 * ==========================================================
 * Copyright 2012 Twitter, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ========================================================== */

!(function ($) {
  "use strict";

  /* ALERT CLASS DEFINITION
   * ====================== */

  var dismiss = '[data-dismiss="alert"]',
    Alert = function (el) {
      $(el).on("click", dismiss, this.close);
    };

  Alert.prototype = {
    constructor: Alert,

    close: function (e) {
      var $this = $(this),
        selector = $this.attr("data-target"),
        $parent;

      if (!selector) {
        selector = $this.attr("href");
        selector = selector && selector.replace(/.*(?=#[^\s]*$)/, ""); //strip for ie7
      }

      $parent = $(selector);
      $parent.trigger("close");

      e && e.preventDefault();

      $parent.length ||
        ($parent = $this.hasClass("alert") ? $this : $this.parent());

      $parent.trigger("close").removeClass("in");

      function removeElement() {
        $parent.trigger("closed").remove();
      }

      $.support.transition && $parent.hasClass("fade")
        ? $parent.on($.support.transition.end, removeElement)
        : removeElement();
    }
  };

  /* ALERT PLUGIN DEFINITION
   * ======================= */

  $.fn.alert = function (option) {
    return this.each(function () {
      var $this = $(this),
        data = $this.data("alert");
      if (!data) $this.data("alert", (data = new Alert(this)));
      if (typeof option == "string") data[option].call($this);
    });
  };

  $.fn.alert.Constructor = Alert;

  /* ALERT DATA-API
   * ============== */

  $(function () {
    $("body").on("click.alert.data-api", dismiss, Alert.prototype.close);
  });
})(window.jQuery);
/* ============================================================
 * bootstrap-button.js v2.0.1
 * https://twitter.github.com/bootstrap/javascript.html#buttons
 * ============================================================
 * Copyright 2012 Twitter, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ============================================================ */

!(function ($) {
  "use strict";

  /* BUTTON PUBLIC CLASS DEFINITION
   * ============================== */

  var Button = function (element, options) {
    this.$element = $(element);
    this.options = $.extend({}, $.fn.button.defaults, options);
  };

  Button.prototype = {
    constructor: Button,

    setState: function (state) {
      var d = "disabled",
        $el = this.$element,
        data = $el.data(),
        val = $el.is("input") ? "val" : "html";

      state = state + "Text";
      data.resetText || $el.data("resetText", $el[val]());

      $el[val](data[state] || this.options[state]);

      // push to event loop to allow forms to submit
      setTimeout(function () {
        state == "loadingText"
          ? $el.addClass(d).attr(d, d)
          : $el.removeClass(d).removeAttr(d);
      }, 0);
    },

    toggle: function () {
      var $parent = this.$element.parent('[data-toggle="buttons-radio"]');

      $parent && $parent.find(".active").removeClass("active");

      this.$element.toggleClass("active");
    }
  };

  /* BUTTON PLUGIN DEFINITION
   * ======================== */

  $.fn.button = function (option) {
    return this.each(function () {
      var $this = $(this),
        data = $this.data("button"),
        options = typeof option == "object" && option;
      if (!data) $this.data("button", (data = new Button(this, options)));
      if (option == "toggle") data.toggle();
      else if (option) data.setState(option);
    });
  };

  $.fn.button.defaults = {
    loadingText: "loading..."
  };

  $.fn.button.Constructor = Button;

  /* BUTTON DATA-API
   * =============== */

  $(function () {
    $("body").on(
      "click.button.data-api",
      "[data-toggle^=button]",
      function (e) {
        var $btn = $(e.target);
        if (!$btn.hasClass("btn")) $btn = $btn.closest(".btn");
        $btn.button("toggle");
      }
    );
  });
})(window.jQuery);
/* =============================================================
 * bootstrap-collapse.js v2.0.1
 * https://twitter.github.com/bootstrap/javascript.html#collapse
 * =============================================================
 * Copyright 2012 Twitter, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ============================================================ */

!(function ($) {
  "use strict";

  var Collapse = function (element, options) {
    this.$element = $(element);
    this.options = $.extend({}, $.fn.collapse.defaults, options);

    if (this.options["parent"]) {
      this.$parent = $(this.options["parent"]);
    }

    this.options.toggle && this.toggle();
  };

  Collapse.prototype = {
    constructor: Collapse,

    dimension: function () {
      var hasWidth = this.$element.hasClass("width");
      return hasWidth ? "width" : "height";
    },

    show: function () {
      var dimension = this.dimension(),
        scroll = $.camelCase(["scroll", dimension].join("-")),
        actives = this.$parent && this.$parent.find(".in"),
        hasData;

      if (actives && actives.length) {
        hasData = actives.data("collapse");
        actives.collapse("hide");
        hasData || actives.data("collapse", null);
      }

      this.$element[dimension](0);
      this.transition("addClass", "show", "shown");
      this.$element[dimension](this.$element[0][scroll]);
    },

    hide: function () {
      var dimension = this.dimension();
      this.reset(this.$element[dimension]());
      this.transition("removeClass", "hide", "hidden");
      this.$element[dimension](0);
    },

    reset: function (size) {
      var dimension = this.dimension();

      this.$element.removeClass("collapse")[dimension](size || "auto")[0]
        .offsetWidth;

      this.$element.addClass("collapse");
    },

    transition: function (method, startEvent, completeEvent) {
      var that = this,
        complete = function () {
          if (startEvent == "show") that.reset();
          that.$element.trigger(completeEvent);
        };

      this.$element.trigger(startEvent)[method]("in");

      $.support.transition && this.$element.hasClass("collapse")
        ? this.$element.one($.support.transition.end, complete)
        : complete();
    },

    toggle: function () {
      this[this.$element.hasClass("in") ? "hide" : "show"]();
    }
  };

  /* COLLAPSIBLE PLUGIN DEFINITION
   * ============================== */

  $.fn.collapse = function (option) {
    return this.each(function () {
      var $this = $(this),
        data = $this.data("collapse"),
        options = typeof option == "object" && option;
      if (!data) $this.data("collapse", (data = new Collapse(this, options)));
      if (typeof option == "string") data[option]();
    });
  };

  $.fn.collapse.defaults = {
    toggle: true
  };

  $.fn.collapse.Constructor = Collapse;

  /* COLLAPSIBLE DATA-API
   * ==================== */

  $(function () {
    $("body").on(
      "click.collapse.data-api",
      "[data-toggle=collapse]",
      function (e) {
        var $this = $(this),
          href,
          target =
            $this.attr("data-target") ||
            e.preventDefault() ||
            ((href = $this.attr("href")) && href.replace(/.*(?=#[^\s]+$)/, "")), //strip for ie7
          option = $(target).data("collapse") ? "toggle" : $this.data();
        $(target).collapse(option);
      }
    );
  });
})(window.jQuery);
/* ============================================================
 * bootstrap-dropdown.js v2.0.1
 * https://twitter.github.com/bootstrap/javascript.html#dropdowns
 * ============================================================
 * Copyright 2012 Twitter, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ============================================================ */

!(function ($) {
  "use strict";

  /* DROPDOWN CLASS DEFINITION
   * ========================= */

  var toggle = '[data-toggle="dropdown"]',
    Dropdown = function (element) {
      var $el = $(element).on("click.dropdown.data-api", this.toggle);
      $("html").on("click.dropdown.data-api", function () {
        $el.parent().removeClass("open");
      });
    };

  Dropdown.prototype = {
    constructor: Dropdown,

    toggle: function (e) {
      var $this = $(this),
        selector = $this.attr("data-target"),
        $parent,
        isActive;

      if (!selector) {
        selector = $this.attr("href");
        selector = selector && selector.replace(/.*(?=#[^\s]*$)/, ""); //strip for ie7
      }

      $parent = $(selector);
      $parent.length || ($parent = $this.parent());

      isActive = $parent.hasClass("open");

      clearMenus();
      !isActive && $parent.toggleClass("open");

      return false;
    }
  };

  function clearMenus() {
    $(toggle).parent().removeClass("open");
  }

  /* DROPDOWN PLUGIN DEFINITION
   * ========================== */

  $.fn.dropdown = function (option) {
    return this.each(function () {
      var $this = $(this),
        data = $this.data("dropdown");
      if (!data) $this.data("dropdown", (data = new Dropdown(this)));
      if (typeof option == "string") data[option].call($this);
    });
  };

  $.fn.dropdown.Constructor = Dropdown;

  /* APPLY TO STANDARD DROPDOWN ELEMENTS
   * =================================== */

  $(function () {
    $("html").on("click.dropdown.data-api", clearMenus);
    $("body").on("click.dropdown.data-api", toggle, Dropdown.prototype.toggle);
  });
})(window.jQuery);
/* =========================================================
 * bootstrap-modal.js v2.0.1
 * https://twitter.github.com/bootstrap/javascript.html#modals
 * =========================================================
 * Copyright 2012 Twitter, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ========================================================= */

!(function ($) {
  "use strict";

  /* MODAL CLASS DEFINITION
   * ====================== */

  var Modal = function (content, options) {
    this.options = options;
    this.$element = $(content).delegate(
      '[data-dismiss="modal"]',
      "click.dismiss.modal",
      $.proxy(this.hide, this)
    );
  };

  Modal.prototype = {
    constructor: Modal,

    toggle: function () {
      return this[!this.isShown ? "show" : "hide"]();
    },

    show: function () {
      var that = this;

      if (this.isShown) return;

      $("body").addClass("modal-open");

      this.isShown = true;
      this.$element.trigger("show");

      escape.call(this);
      backdrop.call(this, function () {
        var transition = $.support.transition && that.$element.hasClass("fade");

        !that.$element.parent().length && that.$element.appendTo(document.body); //don't move modals dom position

        that.$element.show();

        if (transition) {
          that.$element[0].offsetWidth; // force reflow
        }

        that.$element.addClass("in");

        transition
          ? that.$element.one($.support.transition.end, function () {
              that.$element.trigger("shown");
            })
          : that.$element.trigger("shown");
      });
    },

    hide: function (e) {
      e && e.preventDefault();

      if (!this.isShown) return;

      var that = this;
      this.isShown = false;

      $("body").removeClass("modal-open");

      escape.call(this);

      this.$element.trigger("hide").removeClass("in");

      $.support.transition && this.$element.hasClass("fade")
        ? hideWithTransition.call(this)
        : hideModal.call(this);
    }
  };

  /* MODAL PRIVATE METHODS
   * ===================== */

  function hideWithTransition() {
    var that = this,
      timeout = setTimeout(function () {
        that.$element.off($.support.transition.end);
        hideModal.call(that);
      }, 500);

    this.$element.one($.support.transition.end, function () {
      clearTimeout(timeout);
      hideModal.call(that);
    });
  }

  function hideModal(that) {
    this.$element.hide().trigger("hidden");

    backdrop.call(this);
  }

  function backdrop(callback) {
    var that = this,
      animate = this.$element.hasClass("fade") ? "fade" : "";

    if (this.isShown && this.options.backdrop) {
      var doAnimate = $.support.transition && animate;

      this.$backdrop = $(
        '<div class="modal-backdrop ' + animate + '" />'
      ).appendTo(document.body);

      if (this.options.backdrop != "static") {
        this.$backdrop.click($.proxy(this.hide, this));
      }

      if (doAnimate) this.$backdrop[0].offsetWidth; // force reflow

      this.$backdrop.addClass("in");

      doAnimate
        ? this.$backdrop.one($.support.transition.end, callback)
        : callback();
    } else if (!this.isShown && this.$backdrop) {
      this.$backdrop.removeClass("in");

      $.support.transition && this.$element.hasClass("fade")
        ? this.$backdrop.one(
            $.support.transition.end,
            $.proxy(removeBackdrop, this)
          )
        : removeBackdrop.call(this);
    } else if (callback) {
      callback();
    }
  }

  function removeBackdrop() {
    this.$backdrop.remove();
    this.$backdrop = null;
  }

  function escape() {
    var that = this;
    if (this.isShown && this.options.keyboard) {
      $(document).on("keyup.dismiss.modal", function (e) {
        e.which == 27 && that.hide();
      });
    } else if (!this.isShown) {
      $(document).off("keyup.dismiss.modal");
    }
  }

  /* MODAL PLUGIN DEFINITION
   * ======================= */

  $.fn.modal = function (option) {
    return this.each(function () {
      var $this = $(this),
        data = $this.data("modal"),
        options = $.extend(
          {},
          $.fn.modal.defaults,
          $this.data(),
          typeof option == "object" && option
        );
      if (!data) $this.data("modal", (data = new Modal(this, options)));
      if (typeof option == "string") data[option]();
      else if (options.show) data.show();
    });
  };

  $.fn.modal.defaults = {
    backdrop: true,
    keyboard: true,
    show: true
  };

  $.fn.modal.Constructor = Modal;

  /* MODAL DATA-API
   * ============== */

  $(function () {
    $("body").on("click.modal.data-api", '[data-toggle="modal"]', function (e) {
      var $this = $(this),
        href,
        $target = $(
          $this.attr("data-target") ||
            ((href = $this.attr("href")) && href.replace(/.*(?=#[^\s]+$)/, ""))
        ), //strip for ie7
        option = $target.data("modal")
          ? "toggle"
          : $.extend({}, $target.data(), $this.data());

      e.preventDefault();
      $target.modal(option);
    });
  });
})(window.jQuery);
/* ===========================================================
 * bootstrap-popover.js v2.0.1
 * https://twitter.github.com/bootstrap/javascript.html#popovers
 * ===========================================================
 * Copyright 2012 Twitter, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =========================================================== */

!(function ($) {
  "use strict";

  var Popover = function (element, options) {
    this.init("popover", element, options);
  };

  /* NOTE: POPOVER EXTENDS BOOTSTRAP-TOOLTIP.js
     ========================================== */

  Popover.prototype = $.extend({}, $.fn.tooltip.Constructor.prototype, {
    constructor: Popover,

    setContent: function () {
      var $tip = this.tip(),
        title = this.getTitle(),
        content = this.getContent();

      $tip
        .find(".popover-title")
        [$.type(title) == "object" ? "append" : "html"](title);
      $tip
        .find(".popover-content > *")
        [$.type(content) == "object" ? "append" : "html"](content);

      $tip.removeClass("fade top bottom left right in");
    },

    hasContent: function () {
      return this.getTitle() || this.getContent();
    },

    getContent: function () {
      var content,
        $e = this.$element,
        o = this.options;

      content =
        $e.attr("data-content") ||
        (typeof o.content == "function" ? o.content.call($e[0]) : o.content);

      content = content.toString().replace(/(^\s*|\s*$)/, "");

      return content;
    },

    tip: function () {
      if (!this.$tip) {
        this.$tip = $(this.options.template);
      }
      return this.$tip;
    }
  });

  /* POPOVER PLUGIN DEFINITION
   * ======================= */

  $.fn.popover = function (option) {
    return this.each(function () {
      var $this = $(this),
        data = $this.data("popover"),
        options = typeof option == "object" && option;
      if (!data) $this.data("popover", (data = new Popover(this, options)));
      if (typeof option == "string") data[option]();
    });
  };

  $.fn.popover.Constructor = Popover;

  $.fn.popover.defaults = $.extend({}, $.fn.tooltip.defaults, {
    placement: "right",
    content: "",
    template:
      '<div class="popover"><div class="arrow"></div><div class="popover-inner"><h3 class="popover-title"></h3><div class="popover-content"><p></p></div></div></div>'
  });
})(window.jQuery);
/* =============================================================
 * bootstrap-scrollspy.js v2.0.1
 * https://twitter.github.com/bootstrap/javascript.html#scrollspy
 * =============================================================
 * Copyright 2012 Twitter, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ============================================================== */

!(function ($) {
  "use strict";

  /* SCROLLSPY CLASS DEFINITION
   * ========================== */

  function ScrollSpy(element, options) {
    var process = $.proxy(this.process, this),
      $element = $(element).is("body") ? $(window) : $(element),
      href;
    this.options = $.extend({}, $.fn.scrollspy.defaults, options);
    this.$scrollElement = $element.on("scroll.scroll.data-api", process);
    this.selector =
      (this.options.target ||
        ((href = $(element).attr("href")) &&
          href.replace(/.*(?=#[^\s]+$)/, "")) || //strip for ie7
        "") + " .nav li > a";
    this.$body = $("body").on("click.scroll.data-api", this.selector, process);
    this.refresh();
    this.process();
  }

  ScrollSpy.prototype = {
    constructor: ScrollSpy,

    refresh: function () {
      this.targets = this.$body.find(this.selector).map(function () {
        var href = $(this).attr("href");
        return /^#\w/.test(href) && $(href).length ? href : null;
      });

      this.offsets = $.map(this.targets, function (id) {
        return $(id).position().top;
      });
    },

    process: function () {
      var scrollTop = this.$scrollElement.scrollTop() + this.options.offset,
        offsets = this.offsets,
        targets = this.targets,
        activeTarget = this.activeTarget,
        i;

      for (i = offsets.length; i--; ) {
        activeTarget != targets[i] &&
          scrollTop >= offsets[i] &&
          (!offsets[i + 1] || scrollTop <= offsets[i + 1]) &&
          this.activate(targets[i]);
      }
    },

    activate: function (target) {
      var active;

      this.activeTarget = target;

      this.$body.find(this.selector).parent(".active").removeClass("active");

      active = this.$body
        .find(this.selector + '[href="' + target + '"]')
        .parent("li")
        .addClass("active");

      if (active.parent(".dropdown-menu")) {
        active.closest("li.dropdown").addClass("active");
      }
    }
  };

  /* SCROLLSPY PLUGIN DEFINITION
   * =========================== */

  $.fn.scrollspy = function (option) {
    return this.each(function () {
      var $this = $(this),
        data = $this.data("scrollspy"),
        options = typeof option == "object" && option;
      if (!data) $this.data("scrollspy", (data = new ScrollSpy(this, options)));
      if (typeof option == "string") data[option]();
    });
  };

  $.fn.scrollspy.Constructor = ScrollSpy;

  $.fn.scrollspy.defaults = {
    offset: 10
  };

  /* SCROLLSPY DATA-API
   * ================== */

  $(function () {
    $('[data-spy="scroll"]').each(function () {
      var $spy = $(this);
      $spy.scrollspy($spy.data());
    });
  });
})(window.jQuery);
/* ========================================================
 * bootstrap-tab.js v2.0.1
 * https://twitter.github.com/bootstrap/javascript.html#tabs
 * ========================================================
 * Copyright 2012 Twitter, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ======================================================== */

!(function ($) {
  "use strict";

  /* TAB CLASS DEFINITION
   * ==================== */

  var Tab = function (element) {
    this.element = $(element);
  };

  Tab.prototype = {
    constructor: Tab,

    show: function () {
      var $this = this.element,
        $ul = $this.closest("ul:not(.dropdown-menu)"),
        selector = $this.attr("data-target"),
        previous,
        $target;

      if (!selector) {
        selector = $this.attr("href");
        selector = selector && selector.replace(/.*(?=#[^\s]*$)/, ""); //strip for ie7
      }

      if ($this.parent("li").hasClass("active")) return;

      previous = $ul.find(".active a").last()[0];

      $this.trigger({
        type: "show",
        relatedTarget: previous
      });

      $target = $(selector);

      this.activate($this.parent("li"), $ul);
      this.activate($target, $target.parent(), function () {
        $this.trigger({
          type: "shown",
          relatedTarget: previous
        });
      });
    },

    activate: function (element, container, callback) {
      var $active = container.find("> .active"),
        transition =
          callback && $.support.transition && $active.hasClass("fade");

      function next() {
        $active
          .removeClass("active")
          .find("> .dropdown-menu > .active")
          .removeClass("active");

        element.addClass("active");

        if (transition) {
          element[0].offsetWidth; // reflow for transition
          element.addClass("in");
        } else {
          element.removeClass("fade");
        }

        if (element.parent(".dropdown-menu")) {
          element.closest("li.dropdown").addClass("active");
        }

        callback && callback();
      }

      transition ? $active.one($.support.transition.end, next) : next();

      $active.removeClass("in");
    }
  };

  /* TAB PLUGIN DEFINITION
   * ===================== */

  $.fn.tab = function (option) {
    return this.each(function () {
      var $this = $(this),
        data = $this.data("tab");
      if (!data) $this.data("tab", (data = new Tab(this)));
      if (typeof option == "string") data[option]();
    });
  };

  $.fn.tab.Constructor = Tab;

  /* TAB DATA-API
   * ============ */

  $(function () {
    $("body").on(
      "click.tab.data-api",
      '[data-toggle="tab"], [data-toggle="pill"]',
      function (e) {
        e.preventDefault();
        $(this).tab("show");
      }
    );
  });
})(window.jQuery);
/* ===========================================================
 * bootstrap-tooltip.js v2.0.1
 * https://twitter.github.com/bootstrap/javascript.html#tooltips
 * Inspired by the original jQuery.tipsy by Jason Frame
 * ===========================================================
 * Copyright 2012 Twitter, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ========================================================== */

!(function ($) {
  "use strict";

  /* TOOLTIP PUBLIC CLASS DEFINITION
   * =============================== */

  var Tooltip = function (element, options) {
    this.init("tooltip", element, options);
  };

  Tooltip.prototype = {
    constructor: Tooltip,

    init: function (type, element, options) {
      var eventIn, eventOut;

      this.type = type;
      this.$element = $(element);
      this.options = this.getOptions(options);
      this.enabled = true;

      if (this.options.trigger != "manual") {
        eventIn = this.options.trigger == "hover" ? "mouseenter" : "focus";
        eventOut = this.options.trigger == "hover" ? "mouseleave" : "blur";
        this.$element.on(
          eventIn,
          this.options.selector,
          $.proxy(this.enter, this)
        );
        this.$element.on(
          eventOut,
          this.options.selector,
          $.proxy(this.leave, this)
        );
      }

      this.options.selector
        ? (this._options = $.extend({}, this.options, {
            trigger: "manual",
            selector: ""
          }))
        : this.fixTitle();
    },

    getOptions: function (options) {
      options = $.extend(
        {},
        $.fn[this.type].defaults,
        options,
        this.$element.data()
      );

      if (options.delay && typeof options.delay == "number") {
        options.delay = {
          show: options.delay,
          hide: options.delay
        };
      }

      return options;
    },

    enter: function (e) {
      var self = $(e.currentTarget)[this.type](this._options).data(this.type);

      if (!self.options.delay || !self.options.delay.show) {
        self.show();
      } else {
        self.hoverState = "in";
        setTimeout(function () {
          if (self.hoverState == "in") {
            self.show();
          }
        }, self.options.delay.show);
      }
    },

    leave: function (e) {
      var self = $(e.currentTarget)[this.type](this._options).data(this.type);

      if (!self.options.delay || !self.options.delay.hide) {
        self.hide();
      } else {
        self.hoverState = "out";
        setTimeout(function () {
          if (self.hoverState == "out") {
            self.hide();
          }
        }, self.options.delay.hide);
      }
    },

    show: function () {
      var $tip, inside, pos, actualWidth, actualHeight, placement, tp;

      if (this.hasContent() && this.enabled) {
        $tip = this.tip();
        this.setContent();

        if (this.options.animation) {
          $tip.addClass("fade");
        }

        placement =
          typeof this.options.placement == "function"
            ? this.options.placement.call(this, $tip[0], this.$element[0])
            : this.options.placement;

        inside = /in/.test(placement);

        $tip
          .remove()
          .css({ top: 0, left: 0, display: "block" })
          .appendTo(inside ? this.$element : document.body);

        pos = this.getPosition(inside);

        actualWidth = $tip[0].offsetWidth;
        actualHeight = $tip[0].offsetHeight;

        switch (inside ? placement.split(" ")[1] : placement) {
          case "bottom":
            tp = {
              top: pos.top + pos.height,
              left: pos.left + pos.width / 2 - actualWidth / 2
            };
            break;
          case "top":
            tp = {
              top: pos.top - actualHeight,
              left: pos.left + pos.width / 2 - actualWidth / 2
            };
            break;
          case "left":
            tp = {
              top: pos.top + pos.height / 2 - actualHeight / 2,
              left: pos.left - actualWidth
            };
            break;
          case "right":
            tp = {
              top: pos.top + pos.height / 2 - actualHeight / 2,
              left: pos.left + pos.width
            };
            break;
        }

        $tip.css(tp).addClass(placement).addClass("in");
      }
    },

    setContent: function () {
      var $tip = this.tip();
      $tip.find(".tooltip-inner").html(this.getTitle());
      $tip.removeClass("fade in top bottom left right");
    },

    hide: function () {
      var that = this,
        $tip = this.tip();

      $tip.removeClass("in");

      function removeWithAnimation() {
        var timeout = setTimeout(function () {
          $tip.off($.support.transition.end).remove();
        }, 500);

        $tip.one($.support.transition.end, function () {
          clearTimeout(timeout);
          $tip.remove();
        });
      }

      $.support.transition && this.$tip.hasClass("fade")
        ? removeWithAnimation()
        : $tip.remove();
    },

    fixTitle: function () {
      var $e = this.$element;
      if (
        $e.attr("title") ||
        typeof $e.attr("data-original-title") != "string"
      ) {
        $e.attr("data-original-title", $e.attr("title") || "").removeAttr(
          "title"
        );
      }
    },

    hasContent: function () {
      return this.getTitle();
    },

    getPosition: function (inside) {
      return $.extend(
        {},
        inside ? { top: 0, left: 0 } : this.$element.offset(),
        {
          width: this.$element[0].offsetWidth,
          height: this.$element[0].offsetHeight
        }
      );
    },

    getTitle: function () {
      var title,
        $e = this.$element,
        o = this.options;

      title =
        $e.attr("data-original-title") ||
        (typeof o.title == "function" ? o.title.call($e[0]) : o.title);

      title = title.toString().replace(/(^\s*|\s*$)/, "");

      return title;
    },

    tip: function () {
      return (this.$tip = this.$tip || $(this.options.template));
    },

    validate: function () {
      if (!this.$element[0].parentNode) {
        this.hide();
        this.$element = null;
        this.options = null;
      }
    },

    enable: function () {
      this.enabled = true;
    },

    disable: function () {
      this.enabled = false;
    },

    toggleEnabled: function () {
      this.enabled = !this.enabled;
    },

    toggle: function () {
      this[this.tip().hasClass("in") ? "hide" : "show"]();
    }
  };

  /* TOOLTIP PLUGIN DEFINITION
   * ========================= */

  $.fn.tooltip = function (option) {
    return this.each(function () {
      var $this = $(this),
        data = $this.data("tooltip"),
        options = typeof option == "object" && option;
      if (!data) $this.data("tooltip", (data = new Tooltip(this, options)));
      if (typeof option == "string") data[option]();
    });
  };

  $.fn.tooltip.Constructor = Tooltip;

  $.fn.tooltip.defaults = {
    animation: true,
    delay: 0,
    selector: false,
    placement: "top",
    trigger: "hover",
    title: "",
    template:
      '<div class="tooltip"><div class="tooltip-arrow"></div><div class="tooltip-inner"></div></div>'
  };
})(window.jQuery);
/* ===================================================
 * bootstrap-transition.js v2.0.1
 * https://twitter.github.com/bootstrap/javascript.html#transitions
 * ===================================================
 * Copyright 2012 Twitter, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ========================================================== */

!(function ($) {
  $(function () {
    "use strict";

    /* CSS TRANSITION SUPPORT (https://gist.github.com/373874)
     * ======================================================= */

    $.support.transition = (function () {
      var thisBody = document.body || document.documentElement,
        thisStyle = thisBody.style,
        support =
          thisStyle.transition !== undefined ||
          thisStyle.WebkitTransition !== undefined ||
          thisStyle.MozTransition !== undefined ||
          thisStyle.MsTransition !== undefined ||
          thisStyle.OTransition !== undefined;

      return (
        support && {
          end: (function () {
            var transitionEnd = "TransitionEnd";
            if ($.browser.webkit) {
              transitionEnd = "webkitTransitionEnd";
            } else if ($.browser.mozilla) {
              transitionEnd = "transitionend";
            } else if ($.browser.opera) {
              transitionEnd = "oTransitionEnd";
            }
            return transitionEnd;
          })()
        }
      );
    })();
  });
})(window.jQuery); /*! http://mths.be/placeholder v2.0.7 by @mathias */
(function (window, document, $) {
  var isOperaMini =
    Object.prototype.toString.call(window.operamini) == "[object OperaMini]";
  var isInputSupported =
    "placeholder" in document.createElement("input") && !isOperaMini;
  var isTextareaSupported =
    "placeholder" in document.createElement("textarea") && !isOperaMini;
  var prototype = $.fn;
  var valHooks = $.valHooks;
  var propHooks = $.propHooks;
  var hooks;
  var placeholder;
  if (isInputSupported && isTextareaSupported) {
    placeholder = prototype.placeholder = function () {
      return this;
    };
    placeholder.input = placeholder.textarea = true;
  } else {
    placeholder = prototype.placeholder = function () {
      var $this = this;
      $this
        .filter((isInputSupported ? "textarea" : ":input") + "[placeholder]")
        .not(".placeholder")
        .bind({
          "focus.placeholder": clearPlaceholder,
          "blur.placeholder": setPlaceholder
        })
        .data("placeholder-enabled", true)
        .trigger("blur.placeholder");
      return $this;
    };
    placeholder.input = isInputSupported;
    placeholder.textarea = isTextareaSupported;
    hooks = {
      get: function (element) {
        var $element = $(element);
        var $passwordInput = $element.data("placeholder-password");
        if ($passwordInput) {
          return $passwordInput[0].value;
        }
        return $element.data("placeholder-enabled") &&
          $element.hasClass("placeholder")
          ? ""
          : element.value;
      },
      set: function (element, value) {
        var $element = $(element);
        var $passwordInput = $element.data("placeholder-password");
        if ($passwordInput) {
          return ($passwordInput[0].value = value);
        }
        if (!$element.data("placeholder-enabled")) {
          return (element.value = value);
        }
        if (value == "") {
          element.value = value;
          if (element != safeActiveElement()) {
            setPlaceholder.call(element);
          }
        } else if ($element.hasClass("placeholder")) {
          clearPlaceholder.call(element, true, value) ||
            (element.value = value);
        } else {
          element.value = value;
        }
        return $element;
      }
    };
    if (!isInputSupported) {
      valHooks.input = hooks;
      propHooks.value = hooks;
    }
    if (!isTextareaSupported) {
      valHooks.textarea = hooks;
      propHooks.value = hooks;
    }
    $(function () {
      $(document).delegate("form", "submit.placeholder", function () {
        var $inputs = $(".placeholder", this).each(clearPlaceholder);
        setTimeout(function () {
          $inputs.each(setPlaceholder);
        }, 10);
      });
    });
    $(window).bind("beforeunload.placeholder", function () {
      $(".placeholder").each(function () {
        this.value = "";
      });
    });
  }
  function args(elem) {
    var newAttrs = {};
    var rinlinejQuery = /^jQuery\d+$/;
    $.each(elem.attributes, function (i, attr) {
      if (attr.specified && !rinlinejQuery.test(attr.name)) {
        newAttrs[attr.name] = attr.value;
      }
    });
    return newAttrs;
  }
  function clearPlaceholder(event, value) {
    var input = this;
    var $input = $(input);
    if (
      input.value == $input.attr("placeholder") &&
      $input.hasClass("placeholder")
    ) {
      if ($input.data("placeholder-password")) {
        $input = $input
          .hide()
          .next()
          .show()
          .attr("id", $input.removeAttr("id").data("placeholder-id"));
        if (event === true) {
          return ($input[0].value = value);
        }
        $input.focus();
      } else {
        input.value = "";
        $input.removeClass("placeholder");
        input == safeActiveElement() && input.select();
      }
    }
  }
  function setPlaceholder() {
    var $replacement;
    var input = this;
    var $input = $(input);
    var id = this.id;
    if (input.value == "") {
      if (input.type == "password") {
        if (!$input.data("placeholder-textinput")) {
          try {
            $replacement = $input.clone().attr({ type: "text" });
          } catch (e) {
            $replacement = $("<input>").attr(
              $.extend(args(this), { type: "text" })
            );
          }
          $replacement
            .removeAttr("name")
            .data({ "placeholder-password": $input, "placeholder-id": id })
            .bind("focus.placeholder", clearPlaceholder);
          $input
            .data({
              "placeholder-textinput": $replacement,
              "placeholder-id": id
            })
            .before($replacement);
        }
        $input = $input.removeAttr("id").hide().prev().attr("id", id).show();
      }
      $input.addClass("placeholder");
      $input[0].value = $input.attr("placeholder");
    } else {
      $input.removeClass("placeholder");
    }
  }
  function safeActiveElement() {
    try {
      return document.activeElement;
    } catch (err) {}
  }
})(this, document, jQuery);
