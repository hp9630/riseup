from django.shortcuts import render
from django.core.mail import EmailMessage
import os
import pdfkit

from django.shortcuts import render,HttpResponse,redirect
from django.contrib.auth.models import User
from django.contrib.auth import authenticate,login,logout


from django.contrib.auth.decorators import login_required


from App.models import *
from django.http import HttpResponse
from io import BytesIO
from django.http import JsonResponse
from django.http import JsonResponse
from django.contrib import messages
from django.template.loader import render_to_string

from django.shortcuts import render
from django.http import HttpResponse
from PIL import Image,ImageDraw,ImageFont
import random
import string
# Create your views here.


# Create your views here.
def Homepage(request):

    return render(request,'index.html')

def generate_captcha():
    # Generate a random string for CAPTCHA
    captcha_string = ''.join(random.choices(string.ascii_uppercase + string.digits, k=6))
    return captcha_string

def signup(request):
    if request.method == 'POST':
        form = UserCreateForm(request.POST)
        user_input = request.POST.get('captcha_input', '').upper()
        captcha_answer = request.session.get('captcha_answer', '')
    
        if form.is_valid() and user_input == captcha_answer:
            new_user = form.save()
            new_user = authenticate(
                username = form.cleaned_data['username'],
                password = form.cleaned_data['password1'],
            )
            login(request,new_user) 
            return redirect('index')
    else:
        form = UserCreateForm() 
        
    
    d={'form':form}
    return render(request,'registration/signup.html',d)


def captcha_image(request):
    # Generate a random CAPTCHA string
    captcha_string = generate_captcha()

    # Store the CAPTCHA string in the session for validation
    request.session['captcha_answer'] = captcha_string

    # Create an image
    width, height = 300, 90 
    image = Image.new('RGB', (width, height), color='white')
    draw = ImageDraw.Draw(image)

    # Choose a font and size
    font_size = 70
    font = ImageFont.truetype("static/as1/fonts/arial.ttf", font_size)
    

    # Calculate text size and position
    text_width, text_height = draw.textsize(captcha_string, font=font)
    x = (width - text_width) / 2
    y = (height - text_height) / 2

    # Draw text on the image
    draw.text((x, y), captcha_string, fill='black', font=font)

    # Save the image to a BytesIO object
    image_io = BytesIO()
    image.save(image_io, format='PNG')
    image_io.seek(0)

    # Return the image as an HTTP response
    return HttpResponse(image_io.getvalue(), content_type='image/png')

def WhatsappData1(ti,wo,n,c,cm):
    import time
    import webbrowser as web
    import pyautogui as pg
    Phone  = "+91"+ c
    Message = ti + wo +cm +" " +n
    web.open('https://api.whatsapp.com/send?phone='+Phone+'&text='+Message)
    time.sleep(10)
    pg.press('enter')
    return redirect('viewwork')

@login_required
def WhatsappData(ph,Message):
    import time
    import webbrowser as web
    import pyautogui as pg
    Phone  = "+91"+ ph
    web.open('https://api.whatsapp.com/send?phone='+Phone+'&text='+Message)
    time.sleep(10)
    pg.press('enter')
@login_required
def senddata(request):
    if request.method=='POST':
        ph = request.POST['Phone']
        Message = request.POST['Message']
        # print(ph,Message)
        WhatsappData(ph,Message)
        msg = "MESSAGE SENT SUCCESSFULLY "
        d={'msg':msg}
        return render(request,'whatsapp.html',d)
    else:
        return HttpResponse("<h1>404- not found</h1>")
@login_required
def viewwork(request):
    #if not request.user.is_staff:
    #     return redirect('login')
    work=Work.objects.all()
    p = {'work':work}
    return render(request,'viewwork.html',p)
@login_required 
def whatsapp(request):
    return render(request,'whatsapp.html')
@login_required
def addwork(request):
    error=""
    #]if not request.user.is_staff:
     #   return redi
    if request.method=='POST':
      ti = request.POST['title']
      wo = request.POST['work']
      na = request.POST['name']
      co = request.POST['contact']
      de = request.POST['description']
      cm = request.POST['comment']
      pn = request.POST['pdfname']
      
      i=request.FILES['image']
      
     
      try:
          Work.objects.create(name=na,work=wo,title=ti,description=de,contact=co,comment=cm,image=i,pdfname=pn)
          error="no"
      except:
          error="yes"
    d = {'error':error}
          
    return render(request,'addwork.html',d)


@login_required
def deletework(request,aid):
    #if not request.user.is_staff:
    #    return redirect('login')
    patient = Work.objects.get(id=aid)
    patient.delete()
    return redirect('viewwork')

@login_required
def editwork(request,id):
    
    work = Work.objects.get(id=id)
    return render(request,'updatework.html',{'work':work,'id':id})
@login_required
def updatework(request,id):
    print(request)

    update = Work.objects.get(id=id)
    #form= DoctorModelForm(request.POST,instance=update)
    #form.save()
    if request.method=='POST':
      if len(request.FILES) !=0:
          if len(update.image)>0:
              os.remove(update.image.path)
              update.image =request.FILES['image']
      ti = request.POST.get('title')
      wo = request.POST.get('work')        
      n = request.POST.get('name')
      c = request.POST.get('contact')
      d = request.POST.get('description')
      cm = request.POST.get('comment')
      
      
      update.title=ti
      update.work=wo
      update.name=n
      update.description=d
      update.contact=c
      update.comment=cm
      
      update.save()
    return redirect('viewwork')
@login_required
def editwork1(request,id):
    
    work = Work.objects.get(id=id)
    return render(request,'sendwork.html',{'work':work,'id':id})
@login_required
def sendwork(request,id):
    print(request)

    update = Work.objects.get(id=id)
    #form= DoctorModelForm(request.POST,instance=update)
    #form.save()
    if request.method=='POST':
      if len(request.FILES) !=0:
          if len(update.image)>0:
              os.remove(update.image.path)
              update.image =request.FILES['image']
      ti = request.POST.get('title')
      wo = request.POST.get('work')        
      n = request.POST.get('name')
      c = request.POST.get('contact')
      d = request.POST.get('description')
      cm = request.POST.get('comment')
      WhatsappData1(ti,wo,n,c,cm )
      
      update.title=ti
      update.work=wo
      update.name=n
      update.description=d
      update.mobile=c
      update.comment=cm
   
    return redirect('viewwork')
######
#work Part end
#####

def usersave(request):
 error=""
 if request.method== 'POST':        
    User_name = request.POST["Username"]
    User_phone = request.POST["Userphone"]
    User_address = request.POST["Useraddress"]
    print()
    pic = request.FILES["photo"]
    
    try:
        UserDetails.objects.create(User_name=User_name, User_phone=User_phone, User_address=User_address, User_pic= pic)
        error="no"
    except:
          error="yes"
 d = {'error':error}  
 return render(request, 'capture.html',d)
def upload_image(request):
    if request.method == 'POST':
        form = WebcamImageForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return JsonResponse({'success': True})
    return JsonResponse({'success': False})
@login_required
def adminmain(request):
    #if not request.user.is_staff:
   #     return redirect('login')

    return render(request,'adminmain.html')

def base(request):
    return render(request,'base.html')
@login_required
def editinvoice1(request,id):
    work = Work.objects.get(id=id)
   
    return render(request,'getinvoice1.html',{'id':id,'work':work,})
@login_required
def getinvoice1(request,id):
    
    
    #bill1 = Patient.objects.filter(name=p).first()
    update = Work.objects.get(id=id)
  
    if request.method=='POST':
      title = request.POST.get('title')
      work = request.POST.get('work')
      name = request.POST.get('name')
      description = request.POST.get('description')
      contact = request.POST.get('contact')
      comment = request.POST.get('comment')
      

      update.title=title  
      update.work=work
      update.name=name
      update.description=description
      update.contact=contact
      update.comment=comment
      

      update.save()
      
    return redirect('finalinvoice1')
@login_required
def finalinvoice1(request):
    if request.method=='POST':
      title = request.POST['title']
      work = request.POST['work']
      name = request.POST['name']
      description = request.POST['description']
      contact = request.POST['contact']
      comment = request.POST['comment']
      
   
      
      request.session['title']=title.upper()
      request.session['work']=work
      request.session['name']=name 
      request.session['description']=description  
      request.session['contact']=contact
      request.session['comment']=comment
      
     

      request.session.save()
      
      return render(request,'finalinvoice1.html',{'title':title,'work':work,'name':name,'contact':contact,'comment':comment,'description':description})
    return render(request,'viewwork.html')

