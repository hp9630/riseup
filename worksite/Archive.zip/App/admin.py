from django.contrib import admin
from App.models import *



# Register your models here.
admin.site.register(Work)
admin.site.register(UserDetails)
admin.site.register(WebcamImage)